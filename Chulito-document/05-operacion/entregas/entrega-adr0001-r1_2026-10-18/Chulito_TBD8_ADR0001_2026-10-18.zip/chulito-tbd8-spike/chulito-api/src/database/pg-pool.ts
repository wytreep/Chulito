import { Pool, type PoolConfig } from 'pg';

/**
 * Compatibility-only factory. The API does not create this pool at boot,
 * because ADR-0001 deliberately does not select an ORM or database architecture.
 */
export function createPostgresPool(connectionString: string): Pool {
  const config: PoolConfig = {
    connectionString,
    connectionTimeoutMillis: 3_000,
    max: 2,
  };
  return new Pool(config);
}

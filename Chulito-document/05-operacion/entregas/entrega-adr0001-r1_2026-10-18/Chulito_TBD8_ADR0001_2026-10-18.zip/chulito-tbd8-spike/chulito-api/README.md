# Chulito TBD-8 compatibility spike

This is a disposable compatibility harness generated with the official NestJS CLI 12.0.8 and then reduced to a synthetic health/validation API. It is not the Chulito product backend, does not ingest payment notices, and does not use S-0.1 as field evidence.

## Candidate toolchain

- Node.js 24.22.0 (LTS candidate); Node.js 22.23.3 is the secondary LTS line tested.
- npm 11.19.1 is pinned as the reproducibility tool for install, scripts and audits.
- NestJS core/common/platform/testing 12.1.3; CLI 12.0.8; schematics 12.0.7.
- TypeScript 6.0.3; ESM (`nodenext`) and the Vitest runner scaffolded by Nest CLI 12.
- `@nestjs/config` 12.0.1, `@nestjs/swagger` 12.0.2, `class-validator` 0.15.1 and `class-transformer` 0.5.1.
- PostgreSQL driver `pg` 8.23.1 is compile-checked. The SRS has not selected an ORM or approved a database integration.

All direct versions are exact pins and `package-lock.json` is the reproducibility authority. The accepted Node range in this harness is `^22.22.3 || ^24.15.0`, which observes the NestJS 12 CLI/schematics floor rather than only the lower runtime floor. The matrix runner executes npm 11.19.1 even if the installed Node distribution bundles another npm patch.

## Install, build and test

Run the complete clean matrix from this directory:

```bash
./scripts/run-node-matrix.sh
```

It selects Node 24.22.0 and 22.23.3 through nvm, uses npm 11.19.1 for `ci`, build, typecheck, unit tests, e2e tests, process startup smoke and `audit`, and fails on the first unsuccessful command. For one runtime only, use `nvm use 24.22.0` (or `22.23.3`), then `npx --yes npm@11.19.1 ci` and `npx --yes npm@11.19.1 run verify`.

`verify` exercises the Nest production build, TypeScript typecheck, two unit tests, three HTTP e2e tests (health JSON, request validation and generated `/api/docs-json`), and starts `dist/main.js` to exercise the ESM runtime over loopback. No service needs to listen on a public interface.

## Optional PostgreSQL test

Docker and `psql` were unavailable in the recorded environment, so this step was not executed. If Docker Compose is installed, run:

```bash
./scripts/run-postgres-smoke.sh
```

The script creates a disposable local PostgreSQL 16 container on loopback port 54329, runs a parameterized query through `pg`, then removes the container and volume. The credentials in `postgres/compose.yaml` are local test-only placeholders and must never be reused outside this isolated spike. Without Docker, set `DATABASE_URL` to a disposable PostgreSQL database and run `npx --yes npm@11.19.1 run test:postgres`.

This checks the `pg` client/Node connection path only. It does not select TypeORM, Prisma, Drizzle, migrations, connection pooling policy for production, or a Chulito database schema.

## Evidence

See `../ADR-0001.md`, `../evidence/sources.md`, `../evidence/registry-metadata.json` and `../evidence/verification-2026-10-18.md` for the decision record and dated snapshots/results.
